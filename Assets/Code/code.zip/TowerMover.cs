using UnityEngine;

public class TowerMover : MonoBehaviour
{
    [SerializeField] private TowerSelector towerSelector;
    public Tower selectedTower; // ���� ���õ� Ÿ��
    public Tile tile;
    public bool IsMoving; // �̵� ��� ����

    public void StartMove()
    {
        IsMoving = true;
    }

    public void MoveToTile(Tile tile)
    {
        if (!IsMoving || selectedTower == null)
        {
            EndMove();
            return;
        }

        if (tile.currentTower == null) // �� Ÿ���̸� �̵�
        {
            selectedTower.MoveToTile(tile, false);
            EndMove();
        }
        else // �ٸ� Ÿ���� �ִٸ� ��ġ ��ȯ
        {
            selectedTower.SwapWithTower(tile.currentTower);
            EndMove();
        }
    }

    public void TowerSell()
    {
        if (selectedTower != null)
        {
            selectedTower.RemoveTower();
            GameManager.instance.Gold += 5;
            selectedTower = null;
            TowerInfo.instance.HideUI();
            towerSelector.ResetTile();
        }
    }

    public void EndMove()
    {
        selectedTower = null;
        IsMoving = false;
        Debug.Log("Ÿ�� �̵� ��� ��Ȱ��ȭ");
    }
}
