using UnityEngine;

public class TowerMaker : MonoBehaviour
{
    [SerializeField] private GameObject meleeTowerPrefab;
    [SerializeField] private GameObject rangedTowerPrefab;
    [SerializeField] private GameObject tankTowerPrefab;
    [SerializeField] private Transform towerParent;

    private GameObject selectedTowerPrefab;

    private void Start()
    {
        selectedTowerPrefab = meleeTowerPrefab;  // �⺻ ���� Ÿ��
    }

    public void SelectMeleeTower()
    {
        selectedTowerPrefab = meleeTowerPrefab;
        Debug.Log("�ٰŸ� Ÿ�� ����");
    }

    public void SelectRangedTower()
    {
        selectedTowerPrefab = rangedTowerPrefab;
        Debug.Log("���Ÿ� Ÿ�� ����");
    }

    public void SelectTankTower()
    {
        selectedTowerPrefab = tankTowerPrefab;
        Debug.Log("��Ŀ Ÿ�� ����");
    }

    public void SpawnTower(Tile tile)
    {
        if (selectedTowerPrefab == null) return;

        if (tile.IsBuildTower)
        {
            Debug.Log("�̹� Ÿ���� ��ġ�� Ÿ���Դϴ�!");
            return;
        }

        if (GameManager.instance.Gold < 5) return;

        GameObject towerObject = Instantiate(selectedTowerPrefab, tile.transform.position, Quaternion.identity);
        towerObject.transform.SetParent(towerParent);
        Tower tower = towerObject.GetComponent<Tower>();
        GameManager.instance.Gold -= 5;

        if (tower != null)
        {
            tower.tile = tile; // ��ġ�� Ÿ���� �����ϵ��� ����
            tile.IsBuildTower = true; // ��ġ�� ���·� ����
            tile.currentTower = tower;
        }
    }
}
