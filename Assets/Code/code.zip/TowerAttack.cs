using UnityEditor.Tilemaps;
using UnityEngine;

public class TowerAttack : MonoBehaviour
{
    public Transform firePoint; // ����ü �߻� ��ġ

    public Tower tower;

    private Animator towerAnim;  // Ÿ���� �ִϸ�����
    private SpriteRenderer spriteRenderer;

    public int meleeEffectIndex;
    private bool isAttacking = false;
    public float attackCooldown; // ��Ÿ�� �ð�

    private void Awake()
    {
        firePoint = this.transform;
        towerAnim = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        tower = GetComponent<Tower>();
    }

    private void Update()
    {
        // ��Ÿ�� ����
        if (attackCooldown > 0)
        {
            attackCooldown -= Time.deltaTime;
            if (attackCooldown <= 0)
            {
                isAttacking = false; // ��Ÿ�� ����
            }
        }
    }

    public void Attack(GameObject target)
    {
        if (target == null || isAttacking)
        {
            return;
        }

        Vector2 direction = (target.transform.position - transform.position).normalized;

        // Ÿ���� ������ �ٶ󺸵��� flipX ����
        if (tower.flipX == false) spriteRenderer.flipX = direction.x > 0;
        else spriteRenderer.flipX = !(direction.x > 0);


        switch (tower.towerType)
        {
            case "Melee":
                PerformMeleeAttack(target);
                break;

            case "Range":
                PerformRangeAttack(target);
                break;

            case "Round":
                PerformRoundAttack();
                break;

            case "Heal":
                PerformHeal();
                break;

            default:
                break;
        }
    }

    private void PerformMeleeAttack(GameObject target)
    {
        Enemy enemy = target.GetComponent<Enemy>();
        if (enemy != null)
        {
            enemy.TakeDamage(tower.damage);
        }

        isAttacking = true; // ���� ����
        attackCooldown = tower.speed; // ��Ÿ�� ����
        towerAnim.SetTrigger("Attack"); // �ִϸ��̼� ����

        GameObject effectInstance = GameManager.instance.pool.Get(meleeEffectIndex);
        effectInstance.transform.position = target.transform.position;
        effectInstance.SetActive(true); // ����Ʈ Ȱ��ȭ
    }

    public void PerformRangeAttack(GameObject target)
    {
        GameObject projectileObject = GameManager.instance.pool.Get(tower.projectileIndex); // Ǯ���� ����ü ��������
        projectileObject.transform.position = firePoint.position; // �߻� ��ġ ����
        Projectile projectile = projectileObject.GetComponent<Projectile>();
        if (projectile != null)
        {
            projectile.Init(tower, target); // �ʱ�ȭ �� ��ǥ ����
        }
        isAttacking = true; // ���� ����
        attackCooldown = tower.speed; // ��Ÿ�� ����
        towerAnim.SetTrigger("Attack"); // �ִϸ��̼� ����
    }

    private void PerformRoundAttack()
    {
        // Ÿ�� �ֺ� ���� �� �� ����
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, tower.range);

        foreach (Collider2D enemyCollider in hitEnemies)
        {
            if (enemyCollider.CompareTag("Enemy"))
            {
                Enemy enemy = enemyCollider.GetComponent<Enemy>();
                if (enemy != null || enemy.hp > 0)
                {
                    enemy.TakeDamage(tower.damage); // ������ ������ ����
                    GameObject effectInstance = GameManager.instance.pool.Get(meleeEffectIndex);
                    effectInstance.transform.position = enemy.transform.position;
                    effectInstance.SetActive(true);
                }
            }
        }
        isAttacking = true; // ���� ����
        attackCooldown = tower.speed; // ��Ÿ�� ����
        towerAnim.SetTrigger("Attack"); // �ִϸ��̼� ����
    }

    private void PerformHeal()
    {
        // �ֺ� Ÿ�� ����
        Collider2D[] nearTowers = Physics2D.OverlapCircleAll(transform.position, tower.range);

        foreach (Collider2D towerCollider in nearTowers)
        {
            if (towerCollider.CompareTag("Tower"))
            {
                Tower nearTower = towerCollider.GetComponent<Tower>();
                if (nearTower != null)
                {
                    nearTower.hp += tower.damage; // Ÿ�� ȸ��
                    if (nearTower.hp >= nearTower.maxHp) nearTower.hp = nearTower.maxHp;
                    GameObject effectInstance = GameManager.instance.pool.Get(meleeEffectIndex);
                    effectInstance.transform.position = nearTower.transform.position;
                    effectInstance.SetActive(true);
                }
            }
        }
        isAttacking = true; // �� ����
        attackCooldown = tower.speed; // ��Ÿ�� ����
        towerAnim.SetTrigger("Attack"); // �� �ִϸ��̼� ����
    }
}
